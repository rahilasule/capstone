<?php include '../view/header.php'; ?>
<div id="content">
    <h1>Your Cart</h1>
    <?php if (cart_product_count() == 0) : ?>
        <p>There are no products in your cart.</p><br/>
        <p>
            <button onclick =" history.go(-1);">Back</button>
        </p>
    <?php else: ?>
        <p>To remove an item from your cart, change its quantity to 0.</p>
        <form action="." method="post">
            <input type="hidden" name="action" value="update" />
            <table id="cart">
            <tr id="cart_header">
                <th class="left">Item</th>
                <th class="right">Price</th>
                <th class="right">Quantity</th>
                <th class="right">Total</th>
            </tr>
            <?php foreach ($cart as $product_id => $item) : ?>
            <tr>
                <td><?php echo $item['name']; ?></td>
                <td class="right">
                    <?php echo sprintf('R%.2f', $item['price']); ?>
                </td>
                <td class="right">
                    <input type="text" size="3" class="right"
                           name="items[<?php echo $product_id; ?>]"
                           value="<?php echo $item['quantity']; ?>" />
                </td>
                <td class="right">
                    <?php echo sprintf('R%.2f', $item['total']); ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <tr id="cart_footer" >
                <td colspan="3" class="right" ><b>Balance</b></td>
                <td class="right">
                    <?php echo sprintf('R%.2f', cart_balance()); ?>
                </td></tr>
                <tr>
                <td colspan="4" class="right">
                    <input type="submit" value="Update Cart" />
                </td>
            </tr> 
            
            
     </table>
   </form>
    <?php endif; ?> 
    <p>Return to: <a href="../"><img src = "../images/home.png" width ="30" height="30">Home</a></p>

    <!-- display most recent category -->
    <?php if (isset($_SESSION['last_category_id'])) :
            $category_url = '../catalog' .
                '?category_id=' . $_SESSION['last_category_id'];
        ?>
        <p>Return to: <a href="<?php echo $category_url; ?>"><img src = "../images/category.png" width ="30" height="30">
            <?php echo $_SESSION['last_category_name']; ?></a></p>
    <?php endif; ?>
 <!-- if cart has items, display the Checkout -->
            <?php if (cart_product_count() > 0) : ?>
        <p>
            Proceed to: <a href="../sales/index.php"><img src = "../images/Payments.jpg" width ="30" height="30">Checkout</a>
        </p>
        <?php endif; ?>  
</div>

<?php include '../view/footer.php'; ?>