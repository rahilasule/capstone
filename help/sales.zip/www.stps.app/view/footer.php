        </div><!-- end main -->
        <div class ="noprint">
        <div id="footer">

       <p class="copyright">
                &copy; <?php echo date("Y"); ?> STPS
            </p> 
      
        </div>
        </div><!-- end footer -->
    </div><!-- end page -->
        
    </body>
</html>